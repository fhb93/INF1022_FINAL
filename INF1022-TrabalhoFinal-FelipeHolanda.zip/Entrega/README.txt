INF1022_FINAL
Trabalho Final da Disciplina 
INF1022 - Analisadores Léxicos e Sintáticos
Felipe Holanda Bezerra

- Para executar: navegar para a pasta bin e executar run.sh com um dos testes como parametro:
Para rodar o teste1:    ./run.sh teste1.txt

Entrega/
|   enunciado-projeto-final.pdf
|   README.txt
|   bin/
|   |   provolonec - executavel do compilador de Provol-One, gerado pelo script ../src/build.sh 
|   |   run.sh - script para execucao do projeto
|   |   teste1.txt - teste baseado no enunciado
|   |   teste2.txt - teste baseado no enunciado com while, =, inc e zera
|   |   teste3.txt - teste com if-then
|   |   teste4.txt - teste com if-then-else
|   |   teste5.txt - teste com mais de um valor de retorno
|   |   teste6.txt - teste com ifs aninhados
|   src/
|   |   build.sh - script de build da pasta src
|   |   lex.yy.c - arquivo .c gerado a partir do lex
|   |   provolonec.l - arquivo lex
|   |   provolonec.tab.c - arquivo .c gerado a partir do yacc
|   |   provolonec.tab.h - arquivo .h gerado a partir do yacc
|   \   provolonec.y - arquivo yacc
\


